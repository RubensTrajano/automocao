import pyautogui as p

#p.click(513, 749, interval=0.25) #excel
#p.hotkey('ctrl', 'c', interval=0.35)
p.click(603, 748, interval=0.25) #nerus
p.press('enter', interval=0.25)
p.write('0', interval=0.35)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)

p.alert('continuar')

p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)


p.write('ajuste de saldo', interval=0.35)
p.press('enter', interval=0.25)
p.press('down', interval=0.35)


for i in range(20):
    p.press('enter', interval=0.25)
    p.write('0', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.35)

    p.alert('continuar')

    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.write('ajuste de saldo', interval=0.40)
    p.press('enter', interval=0.25)
    p.press('down', interval=0.40)

    p.alert('continuar')







