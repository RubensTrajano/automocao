import pyautogui as p

#x=566, y=742 click no google
#click nerus x=603, y=748
#click planilha direita x=513, y=749
#colar 1 x=577, y=168
#colar 2 x=594, y=200
p.click(513, 749, interval=0.25) #excel
p.hotkey('ctrl', 'c', interval=0.35)
p.click(603, 748, interval=0.25) #nerus
p.press('p', interval=0.25)
p.write('38', interval=0.35)
p.press('enter', interval=0.25)
p.click(577, 168, interval=0.25) #colar
p.click(button='right')
p.click(594, 200, interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.write('0', interval=0.35)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.alert('continuar')
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.write('ajuste de saldo', interval=0.35)
p.press('enter', interval=0.25)
p.click(513, 749, interval=0.25) #excel
p.press('down', interval=0.35)
p.hotkey('ctrl', 'c', interval=0.35)

for i in range(5):
    p.click(603, 748, interval=0.25)  # nerus
    p.press('p', interval=0.25)
    p.write('38', interval=0.35)
    p.press('enter', interval=0.25)
    p.click(577, 168, interval=0.25)  # colar
    p.click(button='right')
    p.click(594, 200, interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.write('0', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.alert('continuar')
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.write('ajuste de saldo', interval=0.35)
    p.press('enter', interval=0.25)
    p.click(513, 749, interval=0.25)  # excel
    p.press('down', interval=0.35)
    p.hotkey('ctrl', 'c', interval=0.35)


