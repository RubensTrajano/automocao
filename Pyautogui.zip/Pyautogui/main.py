import pyautogui as p

"""

tabela proximo a esquerda nerus a direita
posicao do nerus x=552, y=754
posicao excel x=508, y=745

"""

#nerus tem que esta nos produtos ctrl s
p.click(508, 745)
p.hotkey('ctrl', 'c', interval=0.35)
p.click(552, 754)
p.press('p')
p.hotkey('ctrl', 'v' , interval=0.35)
p.press('enter')
p.hotkey('ctrl', 's' , interval=0.35)
p.press('down')
p.press('down')
p.press('i', interval=0.35)
p.write('38', interval=0.35)
p.press('enter')
p.press('enter', interval=0.35)
p.press('s')
p.press('s')

p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)

p.alert('continuar')


p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('esc', interval=0.25)
p.press('esc', interval=0.25)

for i in range(10):

    p.click(508, 745)
    p.press('down', interval=0.35)
    p.hotkey('ctrl', 'c', interval=0.35)
    p.click(552, 754, interval=0.35)
    p.press('p', interval=0.35)
    p.hotkey('ctrl', 'v', interval=0.35)
    p.press('enter')
    p.hotkey('ctrl', 's', interval=0.35)
    p.press('down')
    p.press('down')
    p.press('i', interval=0.35)
    p.write('38', interval=0.35)
    p.press('enter')
    p.press('enter', interval=0.35)
    p.press('s')
    p.press('s')

    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)

    p.alert('continuar')



    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('enter', interval=0.35)
    p.press('esc', interval=0.35)
    p.press('esc', interval=0.35)















