import pyautogui as p

"""

tabela proximo a esquerda nerus a direita
posicao do nerus x=552, y=754
posicao excel x=508, y=745

"""

#nerus tem que esta nos produtos

#x=566, y=742 click no google
#click nerus 434 677
#click planilha direita 649 666
p.click(566, 742, interval=0.25)

p.click(649, 666, interval=0.25)

p.hotkey('ctrl', 'c', interval=0.35)

p.click(566, 742, interval=0.25)

p.click(434, 677, interval=0.25)


p.press('p', interval=0.25)
p.hotkey('ctrl', 'v', interval=0.35)
p.press('enter', interval=0.25)
p.hotkey('ctrl', 's', interval=0.35)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('tab', interval=0.25)
p.press('enter', interval=0.25)
p.press('f2', interval=0.25)
p.write('tr', interval=0.35)

p.press('enter', interval=0.25)
p.press('enter', interval=0.25)

p.write('09', interval=0.35)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)

p.press('esc', interval=0.25)
p.press('esc', interval=0.25)

p.press('enter', interval=0.25)
p.press('down', interval=0.25)
p.press('enter', interval=0.25)

p.press('del', interval=0.25)
p.press('del', interval=0.25)
p.press('del', interval=0.25)

p.write('09', interval=0.35)
p.press('enter', interval=0.25)
p.press('del', interval=0.25)
p.press('del', interval=0.25)
p.press('del', interval=0.25)
p.press('del', interval=0.40)

p.press('0', interval=0.25)
p.press('0', interval=0.25)
p.press('0', interval=0.40)

p.press('enter', interval=0.25)

p.press('del', interval=0.25)
p.press('del', interval=0.25)
p.press('del', interval=0.25)
p.press('del', interval=0.40)

p.press('0', interval=0.25)
p.press('0', interval=0.25)
p.press('0', interval=0.40)

p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)

p.press('f2', interval=0.25)
p.write('tr', interval=0.35)

p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)
p.press('enter', interval=0.25)

p.click(566, 742, interval=0.25)

p.click(649, 666, interval=0.25)
p.press('up', interval=0.25)
p.hotkey('ctrl', 'c', interval=0.35)

for i in range(10):
    p.click(566, 742, interval=0.25)

    p.click(434, 677, interval=0.25)

    p.press('p', interval=0.25)
    p.hotkey('ctrl', 'v', interval=0.35)
    p.press('enter', interval=0.25)
    p.hotkey('ctrl', 's', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('tab', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('f2', interval=0.25)
    p.write('tr', interval=0.35)

    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.write('09', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.press('esc', interval=0.25)
    p.press('esc', interval=0.25)

    p.press('enter', interval=0.25)
    p.press('down', interval=0.25)
    p.press('enter', interval=0.25)

    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)

    p.write('09', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.40)

    p.press('0', interval=0.25)
    p.press('0', interval=0.25)
    p.press('0', interval=0.40)

    p.press('enter', interval=0.25)

    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.40)

    p.press('0', interval=0.25)
    p.press('0', interval=0.25)
    p.press('0', interval=0.40)

    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.press('f2', interval=0.25)
    p.write('tr', interval=0.35)

    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.click(566, 742, interval=0.25)

    p.click(649, 666, interval=0.25)
    p.press('up', interval=0.25)
    p.hotkey('ctrl', 'c', interval=0.35)

    p.alert('continuar')


00
000









""""
for i in range(1):
    p.click(566, 742, interval=0.25)
    p.click(649, 666, interval=0.25)
    p.press('up', interval=0.25)
    p.hotkey('ctrl', 'c', interval=0.35)

    p.click(566, 742, interval=0.25)

    p.click(434, 677, interval=0.25)

    p.press('p', interval=0.25)
    p.hotkey('ctrl', 'v', interval=0.35)
    p.press('enter', interval=0.35)
    p.hotkey('ctrl', 's', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.press('down', interval=0.25)
    p.press('down', interval=0.25)

    p.press('tab', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('f2', interval=0.25)
    p.write('tr', interval=0.35)

    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.write('09', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.press('esc', interval=0.25)
    p.press('esc', interval=0.25)

    p.press('enter', interval=0.25)
    p.press('down', interval=0.25)
    p.press('enter', interval=0.25)

    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)

    p.write('09', interval=0.35)
    p.press('enter', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.40)

    p.press('0', interval=0.25)
    p.press('0', interval=0.25)
    p.press('0', interval=0.40)

    p.press('enter', interval=0.25)

    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.25)
    p.press('del', interval=0.40)

    p.press('0', interval=0.25)
    p.press('0', interval=0.25)
    p.press('0', interval=0.40)

    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)

    p.press('f2', interval=0.25)
    p.write('tr', interval=0.35)

    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    p.press('enter', interval=0.25)
    
    
"""



















