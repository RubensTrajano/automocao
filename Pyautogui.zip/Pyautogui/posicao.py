import pyautogui as p

a = p.position()

print(a)