print("ola qual o seu nome?" )
c = input()

print(f'ola {c} , como vai voce ')

print('Em qual ano voce nasceu: ')
ano = int(input())

data = 2023

idade = data - ano

print(f'{c} sua voce tem  {idade} anos')

if idade >= 18:
    print('e maior de idade')
else:
    print("e menor de idade ")

